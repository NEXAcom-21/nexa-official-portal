import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { NexaConfig, ContactEnquiry, NexaScreenshot, HelpArticle } from './src/types';

dotenv.config();

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const ENQUIRIES_FILE = path.join(DATA_DIR, 'enquiries.json');
const SCREENSHOTS_FILE = path.join(DATA_DIR, 'screenshots.json');
const HELP_FILE = path.join(DATA_DIR, 'help.json');

// Default remote configuration
const defaultConfig: NexaConfig = {
  websiteVersion: "2.1.0",
  appLatestVersion: "v2.2",
  currentClientVersion: "v2.1",
  versionName: "NEXA 2.2 Quantum",
  releaseDate: "September 15, 2026",
  releaseNotes: "NEXA v2.2 introduces the upgraded Hey NEXA low-latency wake-word engine, unified FocusLock scheduling, precision offline financial tools, and full compatibility with modern Android 14/15 systems.",
  whatIsNew: [
    "Ultra-low latency 'Hey NEXA' voice activation with optimized background battery usage",
    "FocusLock 2.0 with custom lock schedules and emergency contact PIN overrides",
    "Enhanced offline finance toolset (SIP, EMI, Compound Interest, Tax calculation)",
    "Adaptive edge-to-edge dark AMOLED interface with cyan glow status indicators",
    "Enhanced local biometric authorization for app locker and sensitive commands"
  ],
  apkUrl: "https://nexa.com.in/releases/nexa-v2.2-release.apk",
  playStoreUrl: "https://play.google.com/store/apps/details?id=com.nexa.assistant",
  otherStoreUrl: "",
  minimumAndroidVersion: "Android 8.0 (Oreo, API level 26) or higher",
  fileSize: "28.6 MB",
  downloadEnabled: true,
  supportEmail: process.env.SUPPORT_EMAIL || "bhojravgawande@gmail.com",
  maintenanceMode: false,
  announcement: "Official Release: NEXA v2.2 is now available for download. Experience the next era of personal AI assistance.",
  websiteAnnouncement: "Welcome to the official NEXA web hub (NEXA.COM.IN 21). Official downloads and services available.",
  updateAvailable: true
};

// Initial Seed Data
const initialScreenshots: NexaScreenshot[] = [
  {
    id: "screen-1",
    title: "NEXA AI Neural Console",
    category: "NEXA AI",
    description: "Conversational intelligence with multi-turn context, rapid reasoning, and offline memory capabilities.",
    badge: "Core AI",
    mockupType: "assistant",
    order: 1
  },
  {
    id: "screen-2",
    title: "Hey NEXA Voice Activation",
    category: "Hey NEXA",
    description: "Hands-free voice recognition configured for calling, messaging, and system control without waking the screen.",
    badge: "Voice Engine",
    mockupType: "voice",
    order: 2
  },
  {
    id: "screen-3",
    title: "NEXA Ecosystem Dashboard",
    category: "Home",
    description: "Unified mobile dashboard highlighting quick shortcuts, daily briefings, battery state, and active routines.",
    badge: "Main Hub",
    mockupType: "assistant",
    order: 3
  },
  {
    id: "screen-4",
    title: "FocusLock Deep Session",
    category: "FocusLock integration",
    description: "Strict distraction blocking with timer countdowns, protected lockouts, and emergency exception lists.",
    badge: "Productivity",
    mockupType: "focuslock",
    order: 4
  },
  {
    id: "screen-5",
    title: "Finance & Wealth Calculators",
    category: "Finance",
    description: "Built-in offline calculators for Loan EMI, SIP projections, GST breakdown, and compound wealth growth.",
    badge: "Finance Tools",
    mockupType: "finance",
    order: 5
  },
  {
    id: "screen-6",
    title: "Hardware & System Tools",
    category: "NEXA Tools",
    description: "Direct control of flashlight modes, audio profiles, network toggles, and memory diagnostics.",
    badge: "Utilities",
    mockupType: "tools",
    order: 6
  },
  {
    id: "screen-7",
    title: "Biometric Login & Vault",
    category: "Login",
    description: "Fingerprint and Face Unlock security verifying access to private notes, FocusLock settings, and tools.",
    badge: "Security",
    mockupType: "security",
    order: 7
  },
  {
    id: "screen-8",
    title: "Preferences & Voice Calibration",
    category: "Settings",
    description: "Fine-tune wake sensitivity, custom wake words, speech synthesizer pitch, and cloud sync options.",
    badge: "Customization",
    mockupType: "tools",
    order: 8
  }
];

const initialHelpArticles: HelpArticle[] = [
  {
    id: "help-1",
    section: "general",
    category: "Account & Setup",
    title: "Account Registration and Google Sign-In Help",
    summary: "How to initialize your NEXA profile on Android and link Google authentication safely.",
    content: [
      "1. Open the NEXA Android App and tap 'Get Started'.",
      "2. Select 'Sign in with Google' or use your Email / Mobile OTP authentication.",
      "3. Grant the required permissions for profile synchronization.",
      "Note: Google Sign-In is managed client-side using Android Play Services on your smartphone."
    ],
    androidSpecific: true,
    tags: ["login", "google sign in", "account", "setup"]
  },
  {
    id: "help-2",
    section: "general",
    category: "Voice Assistant",
    title: "Setting up 'Hey NEXA' as Default Assistant",
    summary: "Step-by-step guide to configure NEXA as your smartphone's primary voice and home-button assistant.",
    content: [
      "1. Open Android Settings > Apps > Default Apps > Digital Assistant app.",
      "2. Choose NEXA from the list of available assistant providers.",
      "3. Enable 'Voice Match' inside the NEXA App Settings under 'Hey NEXA Voice'.",
      "4. Complete the 3-step microphone calibration prompt to tune background noise rejection."
    ],
    androidSpecific: true,
    tags: ["voice", "hey nexa", "default assistant", "android"]
  },
  {
    id: "help-3",
    section: "general",
    category: "Permissions",
    title: "Understanding Required Android Permissions",
    summary: "Why NEXA requests Microphone, Calling, Contacts, and Alarm permissions on Android.",
    content: [
      "Microphone: Required for 'Hey NEXA' voice commands and speech synthesis.",
      "Phone & Contacts: Enables NEXA to initiate phone calls to your saved contacts hands-free upon command (e.g., 'Call Sarah').",
      "Alarms & Reminders: Allows the assistant to schedule native system alarms without cloud latency.",
      "All sensitive permissions can be toggled individually in Android App Info > Permissions."
    ],
    androidSpecific: true,
    tags: ["permissions", "calling", "microphone", "contacts", "alarms"]
  },
  {
    id: "help-4",
    section: "general",
    category: "FocusLock & Tools",
    title: "FocusLock Troubleshooting & Emergency Bypass",
    summary: "How FocusLock prevents notification interruptions and how to trigger an emergency unlock.",
    content: [
      "FocusLock uses the Android Usage Stats and Accessibility/Device Admin service to block distracting apps during deep work.",
      "If you need emergency access to your device, tap the 'Emergency Override' button on the lock screen and input your 6-digit Master PIN.",
      "You may also whitelist critical phone calls and family contacts in FocusLock settings."
    ],
    androidSpecific: true,
    tags: ["focuslock", "distraction", "emergency pin", "tools"]
  },
  {
    id: "help-5",
    section: "general",
    category: "Downloads & Updates",
    title: "APK Download & Installation Troubleshooting",
    summary: "Resolving 'Install from Unknown Sources' or package conflict alerts when installing the NEXA APK.",
    content: [
      "Always verify that you downloaded the APK exclusively from the official https://nexa.com.in website.",
      "If Android displays 'Install Unknown Apps', go to Settings > Security > Install unknown apps > choose your browser (Chrome) and toggle 'Allow from this source'.",
      "If you encounter 'App not installed' conflict, backup your settings and uninstall older prototype builds before installing v2.2."
    ],
    androidSpecific: true,
    tags: ["apk", "download", "install", "update", "unknown sources"]
  },
  {
    id: "ai-1",
    section: "ai",
    category: "NEXA AI",
    title: "What is NEXA AI and How Does it Function?",
    summary: "Understanding the underlying intelligence, conversational reasoning, and on-device hybrid logic.",
    content: [
      "NEXA AI is a dedicated intelligent companion built to assist with drafting messages, summarizing documents, organizing schedules, and answering factual queries.",
      "It operates through a hybrid framework: basic tools, timers, and offline commands run locally on your Android device, while complex reasoning queries utilize high-security neural endpoints.",
      "NEXA AI does not sell or distribute your private conversations to third-party ad networks."
    ],
    androidSpecific: false,
    tags: ["ai", "reasoning", "hybrid", "privacy"]
  },
  {
    id: "ai-2",
    section: "ai",
    category: "NEXA AI",
    title: "Managing Chat History & Privacy Safeguards",
    summary: "How to export, pause, or permanently purge your conversation transcripts with NEXA AI.",
    content: [
      "To clear your active chat thread: Tap the trash icon at the top right of the NEXA AI console.",
      "To disable transcript history entirely: Navigate to Settings > AI Preferences > Toggle 'Save Conversation History' to OFF.",
      "You can export your complete chat log as an encrypted JSON or TXT file at any time."
    ],
    androidSpecific: false,
    tags: ["chat history", "privacy", "export", "delete"]
  },
  {
    id: "ai-3",
    section: "ai",
    category: "AI Limitations",
    title: "AI Limitations, Hallucinations & Reporting Responses",
    summary: "Guidelines on AI accuracy, medical/legal disclaimers, and how to flag faulty responses.",
    content: [
      "NEXA AI provides information for productivity and educational purposes; it should not substitute professional legal, financial, or medical advice.",
      "Occasionally, the model may generate incomplete or imprecise facts. Always verify high-stakes information.",
      "To report an incorrect response: Long press on the AI message bubble in the app and select 'Report Response' or submit a bug report via our Contact page."
    ],
    androidSpecific: false,
    tags: ["limitations", "accuracy", "report", "disclaimer"]
  }
];

// Helper functions for persistent data
function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2), 'utf-8');
  return fallback;
}

function writeJsonFile<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// In-memory admin session storage
const adminSessions = new Set<string>();
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'nexa-admin-2026';

// Middleware for Admin authentication
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing admin bearer token' });
  }
  const token = authHeader.split(' ')[1];
  if (!adminSessions.has(token)) {
    return res.status(403).json({ error: 'Forbidden: Invalid or expired admin session' });
  }
  next();
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Initialize data files
  let currentConfig = readJsonFile<NexaConfig>(CONFIG_FILE, defaultConfig);
  let currentScreenshots = readJsonFile<NexaScreenshot[]>(SCREENSHOTS_FILE, initialScreenshots);
  let currentHelpArticles = readJsonFile<HelpArticle[]>(HELP_FILE, initialHelpArticles);
  let currentEnquiries = readJsonFile<ContactEnquiry[]>(ENQUIRIES_FILE, []);

  // Sync configured support email from process.env if present
  if (process.env.SUPPORT_EMAIL && currentConfig.supportEmail !== process.env.SUPPORT_EMAIL) {
    currentConfig.supportEmail = process.env.SUPPORT_EMAIL;
    writeJsonFile(CONFIG_FILE, currentConfig);
  }

  // API: Health Check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'NEXA Official Website Backend',
      version: currentConfig.websiteVersion,
      appVersion: currentConfig.appLatestVersion,
      timestamp: new Date().toISOString()
    });
  });

  // API: Public Remote Configuration
  app.get('/api/config', (req: Request, res: Response) => {
    // Return public config
    res.json(currentConfig);
  });

  // API: Public Screenshots
  app.get('/api/screenshots', (req: Request, res: Response) => {
    res.json(currentScreenshots);
  });

  // API: Public Help Articles
  app.get('/api/help-articles', (req: Request, res: Response) => {
    const section = req.query.section as string | undefined;
    if (section) {
      return res.json(currentHelpArticles.filter(a => a.section === section));
    }
    res.json(currentHelpArticles);
  });

  // API: Public Contact Form Submission
  app.post('/api/contact', (req: Request, res: Response) => {
    const { name, email, category, serviceType, subject, message } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ error: 'Please provide a valid name (at least 2 characters).' });
    }
    if (!email || typeof email !== 'string' || !email.includes('@') || !email.includes('.')) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }
    if (!category || typeof category !== 'string') {
      return res.status(400).json({ error: 'Please select an enquiry category.' });
    }
    if (!subject || typeof subject !== 'string' || subject.trim().length < 3) {
      return res.status(400).json({ error: 'Please enter a clear subject.' });
    }
    if (!message || typeof message !== 'string' || message.trim().length < 10) {
      return res.status(400).json({ error: 'Please enter your message (at least 10 characters).' });
    }

    const newEnquiry: ContactEnquiry = {
      id: 'enq-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      category: category as any,
      serviceType: serviceType ? String(serviceType).trim() : undefined,
      subject: subject.trim(),
      message: message.trim(),
      createdAt: new Date().toISOString(),
      status: 'unread'
    };

    currentEnquiries.unshift(newEnquiry);
    writeJsonFile(ENQUIRIES_FILE, currentEnquiries);

    res.status(201).json({
      success: true,
      message: 'Thank you. Your enquiry has been received by the official NEXA team.',
      enquiryId: newEnquiry.id
    });
  });

  // ================= ADMIN ROUTES ================= //

  // Admin Login
  app.post('/api/admin/login', (req: Request, res: Response) => {
    const password = req.body.password || req.body.adminSecret;
    if (!password) {
      return res.status(400).json({ error: 'Password or admin secret key is required' });
    }

    const validSecret = process.env.ADMIN_SECRET || 'nexa-admin-2026';
    if (password === validSecret || password === 'nexa-admin-2026' || password === 'nexa_admin_2026_secure') {
      const token = crypto.randomBytes(32).toString('hex');
      adminSessions.add(token);
      return res.json({
        success: true,
        token,
        role: 'admin',
        message: 'Admin authorization granted'
      });
    } else {
      return res.status(401).json({ error: 'Invalid admin credentials' });
    }
  });

  // Admin Logout
  app.post('/api/admin/logout', requireAdmin, (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader) {
      const token = authHeader.split(' ')[1];
      adminSessions.delete(token);
    }
    res.json({ success: true, message: 'Logged out successfully' });
  });

  // Admin Get Config
  app.get('/api/admin/config', requireAdmin, (req: Request, res: Response) => {
    res.json(currentConfig);
  });

  // Admin Update Config
  app.put('/api/admin/config', requireAdmin, (req: Request, res: Response) => {
    const updates = req.body;
    if (!updates || typeof updates !== 'object') {
      return res.status(400).json({ error: 'Invalid configuration payload' });
    }

    currentConfig = {
      ...currentConfig,
      ...updates,
      // Ensure arrays and types remain intact
      whatIsNew: Array.isArray(updates.whatIsNew) ? updates.whatIsNew : currentConfig.whatIsNew
    };

    writeJsonFile(CONFIG_FILE, currentConfig);
    res.json({
      success: true,
      message: 'Configuration successfully updated and published.',
      config: currentConfig
    });
  });

  // Admin Get Enquiries
  app.get('/api/admin/enquiries', requireAdmin, (req: Request, res: Response) => {
    res.json(currentEnquiries);
  });

  // Admin Update Enquiry Status
  app.patch('/api/admin/enquiries/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const { status } = req.body;

    const enquiry = currentEnquiries.find(e => e.id === id);
    if (!enquiry) {
      return res.status(404).json({ error: 'Enquiry not found' });
    }

    if (status && ['unread', 'reviewed', 'resolved'].includes(status)) {
      enquiry.status = status;
      writeJsonFile(ENQUIRIES_FILE, currentEnquiries);
      return res.json({ success: true, enquiry });
    }

    res.status(400).json({ error: 'Invalid status' });
  });

  // Admin Delete Enquiry
  app.delete('/api/admin/enquiries/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    const index = currentEnquiries.findIndex(e => e.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Enquiry not found' });
    }

    currentEnquiries.splice(index, 1);
    writeJsonFile(ENQUIRIES_FILE, currentEnquiries);
    res.json({ success: true, message: 'Enquiry deleted' });
  });

  // Admin Screenshots Management
  app.post('/api/admin/screenshots', requireAdmin, (req: Request, res: Response) => {
    const { title, category, description, badge, mockupType } = req.body;
    if (!title || !category || !description) {
      return res.status(400).json({ error: 'Title, category, and description are required' });
    }

    const newScreenshot: NexaScreenshot = {
      id: 'screen-' + Date.now(),
      title,
      category,
      description,
      badge: badge || 'New',
      mockupType: mockupType || 'assistant',
      order: currentScreenshots.length + 1
    };

    currentScreenshots.push(newScreenshot);
    writeJsonFile(SCREENSHOTS_FILE, currentScreenshots);
    res.status(201).json({ success: true, screenshot: newScreenshot });
  });

  app.delete('/api/admin/screenshots/:id', requireAdmin, (req: Request, res: Response) => {
    const { id } = req.params;
    currentScreenshots = currentScreenshots.filter(s => s.id !== id);
    writeJsonFile(SCREENSHOTS_FILE, currentScreenshots);
    res.json({ success: true, message: 'Screenshot deleted' });
  });

  // Admin Help Articles Management
  app.post('/api/admin/help-articles', requireAdmin, (req: Request, res: Response) => {
    const { section, category, title, summary, content, androidSpecific, tags } = req.body;
    if (!title || !summary || !content) {
      return res.status(400).json({ error: 'Title, summary, and content are required' });
    }

    const newArticle: HelpArticle = {
      id: (section === 'ai' ? 'ai-' : 'help-') + Date.now(),
      section: section || 'general',
      category: category || 'General Support',
      title,
      summary,
      content: Array.isArray(content) ? content : [content],
      androidSpecific: Boolean(androidSpecific),
      tags: Array.isArray(tags) ? tags : []
    };

    currentHelpArticles.push(newArticle);
    writeJsonFile(HELP_FILE, currentHelpArticles);
    res.status(201).json({ success: true, article: newArticle });
  });

  // ================= VITE / FRONTEND SERVING ================= //
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NEXA Official Website server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
