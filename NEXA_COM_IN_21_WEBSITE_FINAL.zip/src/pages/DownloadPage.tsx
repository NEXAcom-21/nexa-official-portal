import React, { useState } from 'react';
import {
  Download,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  HelpCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Clock,
  Layers,
  Sparkles
} from 'lucide-react';
import { NexaConfig } from '../types';

interface DownloadPageProps {
  config: NexaConfig | null;
  onNavigate: (page: string) => void;
}

export const DownloadPage: React.FC<DownloadPageProps> = ({ config, onNavigate }) => {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  const version = config?.appLatestVersion || 'v2.2';
  const releaseDate = config?.releaseDate || 'September 15, 2026';
  const fileSize = config?.fileSize || '28.6 MB';
  const minAndroid = config?.minimumAndroidVersion || 'Android 8.0 (Oreo, API level 26) or higher';
  const releaseNotes = config?.releaseNotes || 'NEXA v2.2 introduces the upgraded Hey NEXA low-latency wake-word engine, unified FocusLock scheduling, precision offline financial tools, and full compatibility with modern Android 14/15 systems.';
  const whatIsNew = config?.whatIsNew || [
    "Ultra-low latency 'Hey NEXA' voice activation with optimized background battery usage",
    "FocusLock 2.0 with custom lock schedules and emergency contact PIN overrides",
    "Enhanced offline finance toolset (SIP, EMI, Compound Interest, Tax calculation)",
    "Adaptive edge-to-edge dark AMOLED interface with cyan glow status indicators",
    "Enhanced local biometric authorization for app locker and sensitive commands"
  ];

  const apkUrl = config?.apkUrl?.trim();
  const playStoreUrl = config?.playStoreUrl?.trim();
  const otherStoreUrl = config?.otherStoreUrl?.trim();
  const downloadEnabled = config?.downloadEnabled ?? true;

  const installSteps = [
    {
      step: 1,
      title: 'Download the Official APK File',
      desc: 'Tap the [Download APK] button below. Verify that your browser downloads from the official domain (nexa.com.in).'
    },
    {
      step: 2,
      title: 'Allow Installation from Your Browser',
      desc: 'If Android displays "Install unknown apps", tap Settings > Toggle "Allow from this source" for Chrome/browser.'
    },
    {
      step: 3,
      title: 'Complete System Package Installation',
      desc: 'Tap "Install" when prompted by the Android Package Installer. The app will verify the authentic NEXA.COM.IN 21 signature.'
    },
    {
      step: 4,
      title: 'Launch NEXA & Grant Requested Permissions',
      desc: 'Open NEXA. Configure microphone for "Hey NEXA" voice recognition and set as default assistant if desired.'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 space-y-12">
      {/* Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
          <Smartphone className="w-3.5 h-3.5" />
          OFFICIAL ANDROID DISTRIBUTION
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Download NEXA for Android
        </h1>
        <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
          Install the authentic NEXA Android application to activate the Hey NEXA voice assistant, FocusLock distraction prevention, and offline finance utilities.
        </p>
      </div>

      {/* Primary Download Card */}
      <div className="max-w-4xl mx-auto rounded-3xl bg-[#060c18] border border-cyan-500/30 shadow-2xl overflow-hidden">
        {/* Release Status Banner */}
        <div className="bg-gradient-to-r from-cyan-950/90 via-blue-950/80 to-slate-950 px-6 py-4 border-b border-cyan-500/30 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></div>
            <div>
              <span className="text-xs font-mono text-cyan-300 uppercase">Current Official Version</span>
              <div className="text-lg font-black text-white font-mono">{version}</div>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-300">
            <div>Release Date: <span className="text-white font-semibold">{releaseDate}</span></div>
            <span className="text-slate-600 hidden sm:inline">|</span>
            <div>Package Size: <span className="text-white font-semibold">{fileSize}</span></div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-10 space-y-8">
          {/* Download Action Buttons */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Official Download Channels:
            </div>

            {!downloadEnabled ? (
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-sm flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 flex-shrink-0 text-amber-400" />
                <span>Direct downloads are temporarily paused for scheduled maintenance. Please check back shortly.</span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-4">
                {/* 1. Download APK button (only if configured) */}
                {apkUrl && (
                  <a
                    id="download-official-apk-btn"
                    href={apkUrl}
                    download
                    className="flex-1 min-w-[240px] px-6 py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-blue-600 text-slate-950 font-black text-base hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-3 group cursor-pointer"
                  >
                    <Download className="w-5 h-5 text-slate-950 stroke-[2.5] group-hover:translate-y-0.5 transition-transform" />
                    <span>Download APK ({version})</span>
                  </a>
                )}

                {/* 2. Google Play button (only if configured) */}
                {playStoreUrl && (
                  <a
                    id="download-google-play-btn"
                    href={playStoreUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 min-w-[200px] px-6 py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm border border-slate-700 hover:border-cyan-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <span>Google Play</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  </a>
                )}

                {/* 3. Other Official Store (only if configured) */}
                {otherStoreUrl && (
                  <a
                    id="download-other-store-btn"
                    href={otherStoreUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 min-w-[200px] px-6 py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-sm border border-slate-700 hover:border-cyan-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Layers className="w-4 h-4 text-blue-400" />
                    <span>Official Store</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  </a>
                )}
              </div>
            )}

            {/* Note on genuine links */}
            <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
              <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <span>Download only from official NEXA links. All packages are cryptographically signed.</span>
            </div>
          </div>

          {/* Technical Specifications Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-slate-800">
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono">Current Version</div>
              <div className="text-base font-bold text-white mt-1">{version}</div>
              <div className="text-[11px] text-cyan-400 mt-0.5">{config?.versionName || 'NEXA Quantum'}</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono">Supported Android OS</div>
              <div className="text-base font-bold text-white mt-1">{minAndroid}</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Compatible with Android 14 & 15</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="text-xs text-slate-400 font-mono">Package Verification</div>
              <div className="text-base font-bold text-emerald-400 mt-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Official Certificate
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">SHA-256 Verified</div>
            </div>
          </div>

          {/* What's New Section */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              What's New in {version}
            </h3>
            <ul className="space-y-2.5">
              {whatIsNew.map((item, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm text-slate-300">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 flex items-center justify-center text-xs font-mono font-bold flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Release Notes */}
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-sm text-slate-300">
            <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">
              Developer Release Notes
            </div>
            <p className="leading-relaxed">{releaseNotes}</p>
          </div>
        </div>
      </div>

      {/* Installation Guide */}
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white">
            Android Installation Guide
          </h2>
          <p className="text-sm text-slate-400">
            Follow these simple steps to install and calibrate the official NEXA APK on your smartphone.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {installSteps.map((item) => (
            <div
              key={item.step}
              className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-colors space-y-2"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center font-mono font-bold text-sm">
                  {item.step}
                </div>
                <h4 className="font-bold text-white text-sm">{item.title}</h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed pl-11">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Download Safety Warning & Verification */}
      <div className="max-w-4xl mx-auto p-6 rounded-2xl bg-gradient-to-r from-red-950/20 via-slate-900 to-slate-900 border border-red-500/30 space-y-3">
        <div className="flex items-center gap-2.5 text-sm font-bold text-red-300">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
          Critical Security Notice
        </div>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          Never download NEXA APKs from third-party mirrors, re-hosting forums, or untrusted file-sharing repositories. Modified APKs could compromise your Android device permissions, phone call handlers, or biometric security. Official builds are solely hosted and signed at <strong className="text-white">nexa.com.in</strong>.
        </p>
      </div>

      {/* Need Help? Link to Help Center */}
      <div className="text-center space-y-3 pt-6">
        <p className="text-sm text-slate-400">
          Encountering installation issues or have questions regarding permissions?
        </p>
        <button
          id="download-help-center-link"
          onClick={() => onNavigate('help')}
          className="inline-flex items-center gap-2 text-sm font-semibold text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-4 h-4" />
          Visit the NEXA Help Center for APK Troubleshooting
        </button>
      </div>
    </div>
  );
};
