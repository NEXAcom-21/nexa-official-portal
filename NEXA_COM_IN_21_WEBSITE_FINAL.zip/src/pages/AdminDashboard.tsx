import React, { useState, useEffect } from 'react';
import {
  Lock,
  Shield,
  Save,
  CheckCircle2,
  AlertCircle,
  Inbox,
  Image,
  HelpCircle,
  Smartphone,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  Sparkles,
  RefreshCw,
  ExternalLink,
  Layers,
  Calendar,
  FileText
} from 'lucide-react';
import { NexaConfig, NexaEnquiry, NexaScreenshot, HelpArticle, ScreenshotCategory } from '../types';

interface AdminDashboardProps {
  config: NexaConfig | null;
  onConfigUpdated: (newConfig: NexaConfig) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ config, onConfigUpdated }) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('nexa_admin_token'));
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  const [activeTab, setActiveTab] = useState<'config' | 'enquiries' | 'screenshots' | 'help'>('config');

  // Config Form State
  const [editConfig, setEditConfig] = useState<NexaConfig | null>(config);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [saveLoading, setSaveLoading] = useState(false);

  // Enquiries State
  const [enquiries, setEnquiries] = useState<NexaEnquiry[]>([]);
  const [loadingEnquiries, setLoadingEnquiries] = useState(false);
  const [selectedEnquiry, setSelectedEnquiry] = useState<NexaEnquiry | null>(null);

  // Screenshots State
  const [screenshots, setScreenshots] = useState<NexaScreenshot[]>([]);
  const [loadingScreenshots, setLoadingScreenshots] = useState(false);
  const [newScreenshotModal, setNewScreenshotModal] = useState(false);
  const [newScreenshot, setNewScreenshot] = useState<{
    title: string;
    category: ScreenshotCategory;
    description: string;
    mockupType: string;
    badge?: string;
  }>({
    title: '',
    category: 'Home',
    description: '',
    mockupType: 'home',
    badge: ''
  });

  // Help Articles State
  const [helpArticles, setHelpArticles] = useState<HelpArticle[]>([]);
  const [loadingHelp, setLoadingHelp] = useState(false);
  const [newHelpModal, setNewHelpModal] = useState(false);
  const [newHelp, setNewHelp] = useState({
    title: '',
    category: 'general',
    summary: '',
    content: ''
  });

  // Keep local editConfig in sync when prop changes
  useEffect(() => {
    if (config) {
      setEditConfig(config);
    }
  }, [config]);

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminSecret: passwordInput })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Authentication failed.');
      }

      setToken(data.token);
      localStorage.setItem('nexa_admin_token', data.token);
      setPasswordInput('');
    } catch (err: any) {
      setLoginError(err.message || 'Login failed. Please check secret key.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem('nexa_admin_token');
  };

  // Fetch Enquiries
  const fetchEnquiries = async () => {
    if (!token) return;
    setLoadingEnquiries(true);
    try {
      const res = await fetch('/api/admin/enquiries', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.status === 401) {
        handleLogout();
        return;
      }
      const data = await res.json();
      setEnquiries(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingEnquiries(false);
    }
  };

  // Fetch Screenshots
  const fetchScreenshots = async () => {
    setLoadingScreenshots(true);
    try {
      const res = await fetch('/api/screenshots');
      const data = await res.json();
      setScreenshots(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingScreenshots(false);
    }
  };

  // Fetch Help
  const fetchHelp = async () => {
    setLoadingHelp(true);
    try {
      const res = await fetch('/api/help-articles');
      const data = await res.json();
      setHelpArticles(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingHelp(false);
    }
  };

  useEffect(() => {
    if (token) {
      if (activeTab === 'enquiries') fetchEnquiries();
      if (activeTab === 'screenshots') fetchScreenshots();
      if (activeTab === 'help') fetchHelp();
    }
  }, [token, activeTab]);

  // Save Configuration to Server
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !editConfig) return;

    setSaveLoading(true);
    setSaveStatus(null);

    try {
      const res = await fetch('/api/admin/config', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(editConfig)
      });

      if (res.status === 401) {
        handleLogout();
        throw new Error('Session expired. Please log in again.');
      }

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to save configuration.');
      }

      setSaveStatus('Configuration updated and saved to server storage successfully.');
      onConfigUpdated(data.config);
      setTimeout(() => setSaveStatus(null), 4000);
    } catch (err: any) {
      setSaveStatus(`Error: ${err.message}`);
    } finally {
      setSaveLoading(false);
    }
  };

  // Update Enquiry Status
  const handleUpdateEnquiryStatus = async (id: string, status: 'new' | 'in_review' | 'resolved') => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/enquiries/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchEnquiries();
        if (selectedEnquiry?.id === id) {
          setSelectedEnquiry((prev: NexaEnquiry | null) => (prev ? { ...prev, status } : null));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Add Screenshot
  const handleAddScreenshot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    try {
      const res = await fetch('/api/admin/screenshots', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...newScreenshot,
          order: screenshots.length + 1
        })
      });

      if (res.ok) {
        setNewScreenshotModal(false);
        setNewScreenshot({
          title: '',
          category: 'Home',
          description: '',
          mockupType: 'home',
          badge: ''
        });
        fetchScreenshots();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Screenshot
  const handleDeleteScreenshot = async (id: string) => {
    if (!token || !confirm('Are you sure you want to delete this screenshot?')) return;
    try {
      const res = await fetch(`/api/admin/screenshots/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        fetchScreenshots();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Add Help Article
  const handleAddHelp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    try {
      const res = await fetch('/api/admin/help', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...newHelp,
          order: helpArticles.length + 1
        })
      });
      if (res.ok) {
        setNewHelpModal(false);
        setNewHelp({ title: '', category: 'general', summary: '', content: '' });
        fetchHelp();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Delete Help Article
  const handleDeleteHelp = async (id: string) => {
    if (!token || !confirm('Are you sure you want to delete this article?')) return;
    try {
      const res = await fetch(`/api/admin/help/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        fetchHelp();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Helper for What's New items editing
  const handleAddWhatsNew = () => {
    if (!editConfig) return;
    setEditConfig({
      ...editConfig,
      whatIsNew: [...(editConfig.whatIsNew || []), 'New enhancement item']
    });
  };

  const handleUpdateWhatsNew = (index: number, val: string) => {
    if (!editConfig) return;
    const updated = [...editConfig.whatIsNew];
    updated[index] = val;
    setEditConfig({ ...editConfig, whatIsNew: updated });
  };

  const handleRemoveWhatsNew = (index: number) => {
    if (!editConfig) return;
    const updated = editConfig.whatIsNew.filter((_, i) => i !== index);
    setEditConfig({ ...editConfig, whatIsNew: updated });
  };

  // If NOT logged in, display the server-protected login screen
  if (!token) {
    return (
      <div className="max-w-md mx-auto px-4 py-20">
        <div className="rounded-3xl bg-[#060c18] border border-cyan-500/40 p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mx-auto flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold text-white">NEXA Admin Portal</h1>
            <p className="text-xs text-slate-400">
              Server-side authenticated control console for release versions, downloads, and enquiries.
            </p>
          </div>

          {loginError && (
            <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="admin-secret-input" className="text-xs font-semibold text-slate-300">
                Administrator Secret Key
              </label>
              <input
                id="admin-secret-input"
                type="password"
                required
                placeholder="Enter ADMIN_SECRET..."
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-500/80 focus:ring-1 focus:ring-cyan-500/30"
              />
              <p className="text-[11px] text-slate-500">
                Authenticated against server-side environment credentials.
              </p>
            </div>

            <button
              id="admin-login-submit-btn"
              type="submit"
              disabled={loginLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-sm hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Shield className="w-4 h-4 stroke-[2.5]" />
              <span>{loginLoading ? 'Authenticating...' : 'Access Dashboard'}</span>
            </button>
          </form>

          <div className="text-center pt-2 text-[11px] text-slate-500">
            Official Portal: NEXA.COM.IN 21
          </div>
        </div>
      </div>
    );
  }

  // If logged in: Admin Dashboard
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-[#060c18] border border-cyan-500/30">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center justify-center">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-mono text-cyan-400 uppercase">Authenticated Session</div>
            <h1 className="text-xl font-bold text-white">NEXA Administration Console</h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/40 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Active
          </span>
          <button
            id="admin-logout-btn"
            onClick={handleLogout}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Log Out
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          id="admin-tab-config"
          onClick={() => setActiveTab('config')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'config'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          Version & Release Config
        </button>

        <button
          id="admin-tab-enquiries"
          onClick={() => setActiveTab('enquiries')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'enquiries'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Inbox className="w-4 h-4" />
          Enquiries & Submissions
        </button>

        <button
          id="admin-tab-screenshots"
          onClick={() => setActiveTab('screenshots')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'screenshots'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Image className="w-4 h-4" />
          Screenshots Manager
        </button>

        <button
          id="admin-tab-help"
          onClick={() => setActiveTab('help')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 cursor-pointer transition-all ${
            activeTab === 'help'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          Help Center Articles
        </button>
      </div>

      {/* TAB 1: CONFIGURATION & VERSION MANAGEMENT */}
      {activeTab === 'config' && editConfig && (
        <form onSubmit={handleSaveConfig} className="space-y-8">
          {saveStatus && (
            <div
              className={`p-4 rounded-2xl text-sm flex items-center gap-2.5 animate-in fade-in ${
                saveStatus.startsWith('Error')
                  ? 'bg-red-500/10 border border-red-500/30 text-red-300'
                  : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              }`}
            >
              {saveStatus.startsWith('Error') ? (
                <AlertCircle className="w-5 h-5 flex-shrink-0 text-red-400" />
              ) : (
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-400" />
              )}
              <span>{saveStatus}</span>
            </div>
          )}

          {/* Core Version Parameters */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-cyan-400" />
              Application Release Identity
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Latest Version String</label>
                <input
                  type="text"
                  value={editConfig.appLatestVersion}
                  onChange={(e) => setEditConfig({ ...editConfig, appLatestVersion: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                  placeholder="v2.2"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Version Code (Android Integer)</label>
                <input
                  type="number"
                  value={editConfig.appVersionCode}
                  onChange={(e) => setEditConfig({ ...editConfig, appVersionCode: parseInt(e.target.value) || 0 })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Version Codename</label>
                <input
                  type="text"
                  value={editConfig.versionName}
                  onChange={(e) => setEditConfig({ ...editConfig, versionName: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Release Date</label>
                <input
                  type="text"
                  value={editConfig.releaseDate}
                  onChange={(e) => setEditConfig({ ...editConfig, releaseDate: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">APK Package Size</label>
                <input
                  type="text"
                  value={editConfig.fileSize}
                  onChange={(e) => setEditConfig({ ...editConfig, fileSize: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Minimum Android Version</label>
                <input
                  type="text"
                  value={editConfig.minimumAndroidVersion}
                  onChange={(e) => setEditConfig({ ...editConfig, minimumAndroidVersion: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                />
              </div>
            </div>

            {/* Release Notes */}
            <div className="space-y-1.5 pt-2">
              <label className="text-xs font-semibold text-slate-300">Full Release Notes</label>
              <textarea
                rows={3}
                value={editConfig.releaseNotes}
                onChange={(e) => setEditConfig({ ...editConfig, releaseNotes: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm resize-y"
              ></textarea>
            </div>
          </div>

          {/* What's New List */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                What's New Items
              </h2>
              <button
                type="button"
                onClick={handleAddWhatsNew}
                className="px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Item
              </button>
            </div>

            <div className="space-y-2">
              {editConfig.whatIsNew?.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-slate-800 text-slate-400 text-xs font-mono flex items-center justify-center flex-shrink-0">
                    {idx + 1}
                  </span>
                  <input
                    type="text"
                    value={item}
                    onChange={(e) => handleUpdateWhatsNew(idx, e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveWhatsNew(idx)}
                    className="p-2 rounded-lg text-slate-400 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Download URLs & Configuration */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ExternalLink className="w-5 h-5 text-cyan-400" />
              Download Channel Routing
            </h2>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Direct APK Download URL</label>
                <input
                  type="text"
                  value={editConfig.apkUrl}
                  onChange={(e) => setEditConfig({ ...editConfig, apkUrl: e.target.value })}
                  className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                  placeholder="e.g. /downloads/nexa-v2.2.apk or https://..."
                />
                <p className="text-[11px] text-slate-400">
                  When empty, the [Download APK] button is hidden according to security rules.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Google Play Store URL</label>
                  <input
                    type="text"
                    value={editConfig.playStoreUrl}
                    onChange={(e) => setEditConfig({ ...editConfig, playStoreUrl: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                    placeholder="https://play.google.com/store/apps/details?id=..."
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Other Official Store URL</label>
                  <input
                    type="text"
                    value={editConfig.otherStoreUrl}
                    onChange={(e) => setEditConfig({ ...editConfig, otherStoreUrl: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                    placeholder="https://..."
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <input
                  id="enable-download-toggle"
                  type="checkbox"
                  checked={editConfig.downloadEnabled}
                  onChange={(e) => setEditConfig({ ...editConfig, downloadEnabled: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-500 bg-slate-950 border-slate-800"
                />
                <label htmlFor="enable-download-toggle" className="text-xs font-semibold text-slate-300">
                  Allow Public Direct Downloads (Uncheck to pause downloads during maintenance)
                </label>
              </div>
            </div>
          </div>

          {/* Update Banner Controls */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              Website Top Update Banner Controls
            </h2>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <input
                  id="show-banner-toggle"
                  type="checkbox"
                  checked={editConfig.showUpdateBanner}
                  onChange={(e) => setEditConfig({ ...editConfig, showUpdateBanner: e.target.checked })}
                  className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-500 bg-slate-950 border-slate-800"
                />
                <label htmlFor="show-banner-toggle" className="text-xs font-semibold text-slate-300">
                  Display Top Update Banner across all pages
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Banner Announcement Text</label>
                  <input
                    type="text"
                    value={editConfig.updateBannerMessage}
                    onChange={(e) => setEditConfig({ ...editConfig, updateBannerMessage: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Banner Button Label</label>
                  <input
                    type="text"
                    value={editConfig.updateBannerButtonText}
                    onChange={(e) => setEditConfig({ ...editConfig, updateBannerButtonText: e.target.value })}
                    className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Support Email Configuration */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <h2 className="text-lg font-bold text-white">Official Communications Email</h2>
            <div className="space-y-1.5 max-w-md">
              <label className="text-xs font-semibold text-slate-300">Configured Support Gmail</label>
              <input
                type="email"
                value={editConfig.supportEmail}
                onChange={(e) => setEditConfig({ ...editConfig, supportEmail: e.target.value })}
                className="w-full px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm font-mono"
              />
              <p className="text-[11px] text-slate-400">
                This is displayed on contact, privacy, and footer links.
              </p>
            </div>
          </div>

          {/* Submit / Save Button */}
          <div className="flex items-center justify-end gap-4 pt-4">
            <button
              id="admin-save-config-btn"
              type="submit"
              disabled={saveLoading}
              className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-sm hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/25 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4 stroke-[2.5]" />
              <span>{saveLoading ? 'Saving to Server...' : 'Save All Changes'}</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: ENQUIRIES & CONTACT SUBMISSIONS */}
      {activeTab === 'enquiries' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">
              Official Enquiries & Form Submissions ({enquiries.length})
            </h2>
            <button
              onClick={fetchEnquiries}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white flex items-center gap-1.5 text-xs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </button>
          </div>

          {loadingEnquiries ? (
            <div className="text-center py-12 text-slate-400">Loading stored enquiries from server...</div>
          ) : enquiries.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-slate-900/60 border border-slate-800 space-y-2">
              <Inbox className="w-8 h-8 text-slate-600 mx-auto" />
              <div className="text-sm font-bold text-white">No enquiries submitted yet</div>
              <p className="text-xs text-slate-400">
                Messages sent via the Contact page or Services page will appear here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Enquiries List */}
              <div className="lg:col-span-6 space-y-3">
                {enquiries.map((item) => (
                  <div
                    key={item.id}
                    id={`enquiry-row-${item.id}`}
                    onClick={() => setSelectedEnquiry(item)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2 ${
                      selectedEnquiry?.id === item.id
                        ? 'bg-[#060c18] border-cyan-500/40'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{item.name}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                          item.status === 'new'
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                            : item.status === 'in_review'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}
                      >
                        {item.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="text-xs text-cyan-400 font-mono">{item.category}</div>
                    <div className="text-xs text-slate-300 font-semibold">{item.subject}</div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800">
                      <span>{item.email}</span>
                      <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Selected Enquiry Detail */}
              <div className="lg:col-span-6">
                {selectedEnquiry ? (
                  <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 sticky top-24">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-mono uppercase text-cyan-400">
                          {selectedEnquiry.category}
                        </span>
                        <h3 className="text-lg font-bold text-white mt-1">
                          {selectedEnquiry.subject}
                        </h3>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleUpdateEnquiryStatus(selectedEnquiry.id, 'new')}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] text-slate-300 hover:text-white"
                        >
                          New
                        </button>
                        <button
                          onClick={() => handleUpdateEnquiryStatus(selectedEnquiry.id, 'in_review')}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] text-amber-300 hover:text-white"
                        >
                          Review
                        </button>
                        <button
                          onClick={() => handleUpdateEnquiryStatus(selectedEnquiry.id, 'resolved')}
                          className="px-2 py-1 rounded bg-slate-800 text-[10px] text-emerald-300 hover:text-white"
                        >
                          Resolved
                        </button>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                      <div>
                        Sender: <strong className="text-white">{selectedEnquiry.name}</strong>
                      </div>
                      <div>
                        Email: <a href={`mailto:${selectedEnquiry.email}`} className="text-cyan-400 underline">{selectedEnquiry.email}</a>
                      </div>
                      {selectedEnquiry.serviceType && (
                        <div>Service Requested: <strong className="text-white">{selectedEnquiry.serviceType}</strong></div>
                      )}
                      <div>Received: <span className="text-slate-400">{new Date(selectedEnquiry.createdAt).toLocaleString()}</span></div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs font-mono uppercase text-slate-400">Message Body:</div>
                      <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap p-4 rounded-xl bg-slate-950 border border-slate-800">
                        {selectedEnquiry.message}
                      </p>
                    </div>

                    <a
                      href={`mailto:${selectedEnquiry.email}?subject=Re:%20${encodeURIComponent(selectedEnquiry.subject)}`}
                      className="w-full py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all flex items-center justify-center gap-2"
                    >
                      Reply Directly via Email
                    </a>
                  </div>
                ) : (
                  <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-slate-800 text-slate-500 text-xs">
                    Select an enquiry from the list to view complete details.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SCREENSHOTS MANAGER */}
      {activeTab === 'screenshots' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">
              App Screenshots ({screenshots.length})
            </h2>
            <button
              onClick={() => setNewScreenshotModal(true)}
              className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Screenshot
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {screenshots.map((s) => (
              <div key={s.id} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-cyan-400">{s.category}</span>
                  <button
                    onClick={() => handleDeleteScreenshot(s.id)}
                    className="p-1 text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <h4 className="text-sm font-bold text-white">{s.title}</h4>
                <p className="text-xs text-slate-400 line-clamp-2">{s.description}</p>
                <div className="text-[10px] text-slate-500 font-mono">Mockup: {s.mockupType}</div>
              </div>
            ))}
          </div>

          {/* Add Screenshot Modal */}
          {newScreenshotModal && (
            <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
              <form
                onSubmit={handleAddScreenshot}
                className="max-w-md w-full bg-[#060c18] border border-cyan-500/40 rounded-3xl p-6 space-y-4"
              >
                <h3 className="text-lg font-bold text-white">Add Screenshot</h3>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Title</label>
                  <input
                    type="text"
                    required
                    value={newScreenshot.title}
                    onChange={(e) => setNewScreenshot({ ...newScreenshot, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Category</label>
                  <select
                    value={newScreenshot.category}
                    onChange={(e) => setNewScreenshot({ ...newScreenshot, category: e.target.value as ScreenshotCategory })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  >
                    <option value="Home">Home</option>
                    <option value="NEXA AI">NEXA AI</option>
                    <option value="Hey NEXA">Hey NEXA</option>
                    <option value="NEXA Tools">NEXA Tools</option>
                    <option value="Finance">Finance</option>
                    <option value="Settings">Settings</option>
                    <option value="Login">Login</option>
                    <option value="FocusLock integration">FocusLock integration</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Description</label>
                  <textarea
                    rows={3}
                    required
                    value={newScreenshot.description}
                    onChange={(e) => setNewScreenshot({ ...newScreenshot, description: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs resize-y"
                  ></textarea>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Mockup Visual Scheme</label>
                  <select
                    value={newScreenshot.mockupType}
                    onChange={(e) => setNewScreenshot({ ...newScreenshot, mockupType: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  >
                    <option value="home">Home / Assistant Console</option>
                    <option value="assistant">Conversational Neural UI</option>
                    <option value="voice">Voice Detection ("Hey NEXA")</option>
                    <option value="focuslock">FocusLock Lockdown Timer</option>
                    <option value="finance">Finance / SIP Wealth Tool</option>
                    <option value="security">Biometric Gate / Vault</option>
                    <option value="tools">Hardware Tools / Utilities</option>
                  </select>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setNewScreenshotModal(false)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    Save Screenshot
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: HELP CENTER ARTICLES */}
      {activeTab === 'help' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">
              Help Articles ({helpArticles.length})
            </h2>
            <button
              onClick={() => setNewHelpModal(true)}
              className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Article
            </button>
          </div>

          <div className="space-y-3">
            {helpArticles.map((art) => (
              <div key={art.id} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">{art.category}</span>
                  <h4 className="text-sm font-bold text-white">{art.title}</h4>
                  <p className="text-xs text-slate-300">{art.summary}</p>
                </div>
                <button
                  onClick={() => handleDeleteHelp(art.id)}
                  className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Help Article Modal */}
          {newHelpModal && (
            <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
              <form
                onSubmit={handleAddHelp}
                className="max-w-md w-full bg-[#060c18] border border-cyan-500/40 rounded-3xl p-6 space-y-4"
              >
                <h3 className="text-lg font-bold text-white">Add Help Article</h3>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Article Title</label>
                  <input
                    type="text"
                    required
                    value={newHelp.title}
                    onChange={(e) => setNewHelp({ ...newHelp, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Category</label>
                  <select
                    value={newHelp.category}
                    onChange={(e) => setNewHelp({ ...newHelp, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  >
                    <option value="general">General</option>
                    <option value="account">Account & Setup</option>
                    <option value="voice">Voice Assistant</option>
                    <option value="permissions">Permissions</option>
                    <option value="tools">FocusLock & Tools</option>
                    <option value="finance">Finance</option>
                    <option value="download">Download & Updates</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Summary</label>
                  <input
                    type="text"
                    required
                    value={newHelp.summary}
                    onChange={(e) => setNewHelp({ ...newHelp, summary: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-slate-300">Content / Resolution Guide</label>
                  <textarea
                    rows={4}
                    required
                    value={newHelp.content}
                    onChange={(e) => setNewHelp({ ...newHelp, content: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs resize-y"
                  ></textarea>
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setNewHelpModal(false)}
                    className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    Save Article
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
