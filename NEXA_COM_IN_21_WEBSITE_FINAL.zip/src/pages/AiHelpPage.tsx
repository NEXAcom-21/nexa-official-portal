import React from 'react';
import {
  Sparkles,
  Shield,
  History,
  AlertTriangle,
  FileCheck,
  BrainCircuit,
  Lock,
  Flag,
  MessageSquare,
  HelpCircle,
  Smartphone,
  ArrowRight
} from 'lucide-react';

interface AiHelpPageProps {
  onNavigate: (page: string) => void;
}

export const AiHelpPage: React.FC<AiHelpPageProps> = ({ onNavigate }) => {
  const sections = [
    {
      id: 'what-is-ai',
      icon: BrainCircuit,
      title: 'What is NEXA AI?',
      desc: 'NEXA AI is a neural conversational assistant embedded into the NEXA Android app. It is trained to assist users with writing, task breakdown, code analysis, daily schedule organization, and general knowledge queries.',
      points: [
        'Hybrid Architecture: Simple device tools execute locally on your phone; complex reasoning calls secure neural inference endpoints.',
        'Low Latency: Designed for fast response turnaround with optimized token caching.',
        'Adaptive Style: Can adapt its tone from concise technical answers to detailed creative drafts.'
      ]
    },
    {
      id: 'how-to-use',
      icon: MessageSquare,
      title: 'How to Use NEXA AI in the Android App',
      desc: 'NEXA AI is accessible directly through the main tab of the NEXA Android mobile application.',
      points: [
        'Text Input: Open the NEXA app and type any query or task into the bottom neural prompt bar.',
        'Voice Interaction: Say "Hey NEXA, write a quick thank you note to my team" to invoke voice dictation.',
        'Contextual Follow-ups: You can ask multi-turn questions such as "Now translate that to Spanish" and NEXA will maintain context.'
      ]
    },
    {
      id: 'chat-history',
      icon: History,
      title: 'Managing Chat History & Local Memory',
      desc: 'You have full autonomy over your conversational memory and previous transcripts.',
      points: [
        'View Past Chats: Tap the history icon at the top right of the NEXA AI console.',
        'Clear Active Chat: Tap the trash icon to instantly erase current memory context.',
        'Disable History Storage: In Settings > AI Preferences, toggle "Save Conversation History" to OFF.',
        'Local Export: Export your complete conversation logs as an encrypted JSON or plain text file.'
      ]
    },
    {
      id: 'privacy',
      icon: Lock,
      title: 'Privacy & Data Safeguards',
      desc: 'Your privacy is paramount. NEXA is engineered with strict data minimization principles.',
      points: [
        'No Ad Targeting: Your private conversations are never mined, categorized, or sold to advertising networks.',
        'Local Execution Where Possible: Routine commands, phone calls, and alarms stay entirely on your device.',
        'Encrypted In-Transit: All neural queries are transmitted over TLS 1.3 encryption directly to secured endpoints.'
      ]
    },
    {
      id: 'limitations',
      icon: AlertTriangle,
      title: 'AI Limitations & Responsible Use',
      desc: 'Understanding the capabilities and boundaries of neural generative models.',
      points: [
        'Factual Verification: Generative AI may occasionally generate imprecise facts or outdated references. Always double-check critical details.',
        'No Professional Advisory: NEXA AI does not provide licensed medical, legal, or certified financial advice.',
        'Offensive Content Filters: NEXA features strict safety guardrails that refuse generation of harmful, harassing, or illegal content.'
      ]
    },
    {
      id: 'report-responses',
      icon: Flag,
      title: 'Reporting Incorrect or Flawed Responses',
      desc: 'How users help us continuously refine response accuracy and model safety.',
      points: [
        'In-App Flagging: Long-press on any AI response bubble inside the Android app and tap "Report Response".',
        'Select Reason: Choose from Factually Inaccurate, Harmful/Inappropriate, or Broken Formatting.',
        'Web Feedback: You can also submit specific model feedback through our official Contact page under "App Support".'
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 space-y-16">
      {/* Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
          <Sparkles className="w-3.5 h-3.5" />
          INTELLIGENCE SPECIFICATION
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          NEXA AI Help Center
        </h1>
        <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
          Learn how the NEXA AI neural engine works inside the Android application, how conversation history is handled, and our privacy commitments.
        </p>
      </div>

      {/* Distinction Reminder Box */}
      <div className="max-w-4xl mx-auto p-5 rounded-2xl bg-[#060e1c] border border-cyan-500/30 text-xs sm:text-sm text-slate-300 leading-relaxed space-y-2">
        <div className="flex items-center gap-2 font-bold text-white">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          Native Mobile Execution Note:
        </div>
        <p>
          This website serves as the informational and documentation repository for NEXA AI. In accordance with NEXA architecture rules, the complete neural assistant is hosted and operated inside the <strong>NEXA Android App</strong> rather than in a web browser window.
        </p>
      </div>

      {/* Sections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {sections.map((sec) => {
          const Icon = sec.icon;
          return (
            <div
              key={sec.id}
              className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all space-y-4 shadow-xl flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-white">{sec.title}</h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {sec.desc}
                </p>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-800">
                {sec.points.map((pt, pIdx) => (
                  <div key={pIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <span className="text-cyan-400 font-bold">•</span>
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Report or Request Support Footer */}
      <div className="max-w-3xl mx-auto p-8 rounded-3xl bg-slate-900/80 border border-slate-800 text-center space-y-4">
        <h3 className="text-xl font-bold text-white">Need Further Assistance with NEXA AI?</h3>
        <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
          If you have discovered an issue with generative accuracy, token responses, or account integration, reach out to our AI engineering team.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          <button
            id="ai-help-contact-btn"
            onClick={() => onNavigate('contact')}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-sm hover:from-cyan-400 hover:to-blue-500 transition-all cursor-pointer"
          >
            Contact AI Engineering
          </button>
          <button
            id="ai-help-general-help-btn"
            onClick={() => onNavigate('help')}
            className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold border border-slate-700 transition-colors cursor-pointer"
          >
            General Help Center
          </button>
        </div>
      </div>
    </div>
  );
};
