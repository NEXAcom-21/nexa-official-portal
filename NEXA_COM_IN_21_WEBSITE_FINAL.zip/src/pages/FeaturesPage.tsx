import React from 'react';
import {
  Sparkles,
  Mic,
  Shield,
  Calculator,
  Sliders,
  Smartphone,
  PhoneCall,
  Clock,
  Lock,
  BatteryCharging,
  Cpu,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Download
} from 'lucide-react';
import { NexaConfig } from '../types';

interface FeaturesPageProps {
  onNavigate: (page: string) => void;
  config: NexaConfig | null;
}

export const FeaturesPage: React.FC<FeaturesPageProps> = ({ onNavigate, config }) => {
  const version = config?.appLatestVersion || 'v2.2';

  const capabilities = [
    {
      icon: Sparkles,
      title: 'NEXA Conversational AI',
      subtitle: 'Context-Aware Neural Reasoning',
      desc: 'Built-in natural language model assisting with message drafting, schedule optimization, technical questions, and document summaries.',
      bullets: [
        'Multi-turn context retention across conversation threads',
        'Private local memory storage with 1-tap history purge',
        'Adaptive tone configuration (Concise, Professional, Creative)',
        'Zero ad-tracking or conversation sales to data brokers'
      ],
      badge: 'Core Intelligence',
      badgeColor: 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30'
    },
    {
      icon: Mic,
      title: 'Hey NEXA Voice Assistant',
      subtitle: 'Hands-Free Android Automation',
      desc: 'Deep Android system voice assistant capable of replacing Google Assistant as your device default digital assistant provider.',
      bullets: [
        'Hands-free wake-word detection ("Hey NEXA") with low battery footprint',
        'Direct phone call initiation to saved contacts ("Call Sarah on Mobile")',
        'Native system alarms and countdown timers without cloud delay',
        'Quick application launching ("Open Spotify", "Launch Maps")'
      ],
      badge: 'Voice Engine',
      badgeColor: 'text-blue-400 bg-blue-950/60 border-blue-500/30'
    },
    {
      icon: Shield,
      title: 'FocusLock Distraction Barrier',
      subtitle: 'Strict Deep Work & Screen Discipline',
      desc: 'Enforces distraction-free focus intervals by locking access to addictive apps, social media feeds, and non-essential notifications.',
      bullets: [
        'Custom Pomodoro and deep work session timers',
        'Emergency 6-digit Master PIN bypass for urgent situations',
        'Whitelist essential calling and emergency family contacts',
        'Detailed daily focus analytics and temptation statistics'
      ],
      badge: 'Focus System',
      badgeColor: 'text-purple-400 bg-purple-950/60 border-purple-500/30'
    },
    {
      icon: Calculator,
      title: 'NEXA Finance Engine',
      subtitle: '100% Offline Financial Calculations',
      desc: 'Comprehensive math suite providing immediate projections for personal wealth, loans, taxes, and investments without requiring an internet connection.',
      bullets: [
        'Loan EMI calculator with full amortization schedules',
        'SIP (Systematic Investment Plan) wealth projection model',
        'Compound interest and inflation-adjusted retirement planner',
        'Instant GST, sales tax, and currency breakdown'
      ],
      badge: 'Finance Suite',
      badgeColor: 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30'
    },
    {
      icon: Sliders,
      title: 'Hardware & System Utilities',
      subtitle: 'Direct Device Hardware Controls',
      desc: 'One-tap access to critical smartphone hardware functions, audio state toggles, and memory diagnostics.',
      bullets: [
        'SOS strobe and multi-frequency flashlight pulses',
        'Preset audio profiles (Meeting Mute, Loud Outdoors, Silent)',
        'Network telemetry and Wi-Fi latency ping tests',
        'Battery health diagnostics and background app optimizer'
      ],
      badge: 'Hardware Tools',
      badgeColor: 'text-amber-400 bg-amber-950/60 border-amber-500/30'
    },
    {
      icon: Lock,
      title: 'Biometric Security & App Vault',
      subtitle: 'On-Device Privacy Fortification',
      desc: 'Local cryptographic vault protecting your FocusLock settings, private notes, and sensitive voice commands behind biometric gates.',
      bullets: [
        'Android BiometricPrompt integration (Fingerprint / Face Unlock)',
        'Local AES-256 encrypted storage for offline notes and logs',
        'No remote cloud backups of biometric keys',
        'Instant tamper alert upon repeated PIN failures'
      ],
      badge: 'Security Vault',
      badgeColor: 'text-rose-400 bg-rose-950/60 border-rose-500/30'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 space-y-16">
      {/* Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-mono text-cyan-300">
          <Cpu className="w-3.5 h-3.5" />
          SYSTEM ARCHITECTURE & CAPABILITIES
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          The NEXA Ecosystem
        </h1>
        <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
          Explore how NEXA integrates conversational AI, hands-free voice recognition, FocusLock distraction management, and offline tools into one cohesive Android application.
        </p>
      </div>

      {/* Feature Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {capabilities.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between group space-y-6 shadow-xl"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded-full border ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">{item.subtitle}</p>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {item.desc}
                </p>

                <ul className="space-y-2 pt-2 border-t border-slate-800">
                  {item.bullets.map((b, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2 text-[11px] text-cyan-400 font-mono">
                Native Android Capability
              </div>
            </div>
          );
        })}
      </div>

      {/* System Boundaries: Web vs. Android Comparison */}
      <div className="p-8 sm:p-10 rounded-3xl bg-[#060c18] border border-cyan-500/30 space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            Architecture Matrix: Web vs. Android App
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Clear technical division between the public website and the native mobile assistant.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-mono uppercase text-slate-400">
                <th className="py-3 px-4">Feature / Responsibility</th>
                <th className="py-3 px-4">Official Website (nexa.com.in)</th>
                <th className="py-3 px-4 text-cyan-400">NEXA Android App ({version})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-xs sm:text-sm">
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">Hey NEXA Voice Assistant & Wake-Word</td>
                <td className="py-3.5 px-4 text-slate-400 flex items-center gap-1.5">
                  <XCircle className="w-4 h-4 text-slate-500" /> Information only (No voice engine on web)
                </td>
                <td className="py-3.5 px-4 text-cyan-300 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> Full native voice assistant
                </td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">Direct Phone Calls & Native Contacts</td>
                <td className="py-3.5 px-4 text-slate-400 flex items-center gap-1.5">
                  <XCircle className="w-4 h-4 text-slate-500" /> Web browsers cannot trigger phone calls
                </td>
                <td className="py-3.5 px-4 text-cyan-300 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> Android Telecom API integration
                </td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">FocusLock System Screen Blocking</td>
                <td className="py-3.5 px-4 text-slate-400 flex items-center gap-1.5">
                  <XCircle className="w-4 h-4 text-slate-500" /> Not possible via browser sandboxing
                </td>
                <td className="py-3.5 px-4 text-cyan-300 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> Android Accessibility & UsageStats
                </td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">Offline Financial Calculators</td>
                <td className="py-3.5 px-4 text-slate-400 flex items-center gap-1.5">
                  <XCircle className="w-4 h-4 text-slate-500" /> Available exclusively in mobile app
                </td>
                <td className="py-3.5 px-4 text-cyan-300 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> 100% Offline SQLite engine
                </td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">Official APK Releases & Version Updates</td>
                <td className="py-3.5 px-4 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> Primary verified download source
                </td>
                <td className="py-3.5 px-4 text-slate-300">
                  Checks website for latest version updates
                </td>
              </tr>
              <tr>
                <td className="py-3.5 px-4 font-semibold text-white">Client Inquiries & Professional Services</td>
                <td className="py-3.5 px-4 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 inline mr-1.5" /> Commission web, Android & video creation
                </td>
                <td className="py-3.5 px-4 text-slate-400">
                  Links to official website contact portal
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* CTA Section */}
      <div className="text-center space-y-4 pt-4">
        <h3 className="text-xl font-bold text-white">Ready to experience NEXA on your phone?</h3>
        <button
          id="features-download-cta"
          onClick={() => onNavigate('download')}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-sm hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/25 cursor-pointer"
        >
          <Download className="w-4 h-4 stroke-[2.5]" />
          Download Official APK ({version})
        </button>
      </div>
    </div>
  );
};
