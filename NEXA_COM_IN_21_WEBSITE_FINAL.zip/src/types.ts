export interface NexaConfig {
  websiteVersion: string;
  appLatestVersion: string;
  currentClientVersion: string;
  versionName: string;
  releaseDate: string;
  releaseNotes: string;
  whatIsNew: string[];
  apkUrl: string;
  playStoreUrl: string;
  otherStoreUrl: string;
  minimumAndroidVersion: string;
  fileSize: string;
  downloadEnabled: boolean;
  supportEmail: string;
  maintenanceMode: boolean;
  announcement: string;
  websiteAnnouncement: string;
  updateAvailable: boolean;
  appVersionCode?: number;
  showUpdateBanner?: boolean;
  updateBannerMessage?: string;
  updateBannerButtonText?: string;
}

export type EnquiryCategory =
  | 'Contact NEXA'
  | 'Email NEXA'
  | 'Service Enquiry'
  | 'App Support'
  | 'Bug Report'
  | 'Feature Request'
  | 'Business Enquiry'
  | 'Development Enquiry'
  | 'Video Creation Enquiry'
  | 'Image/Design Enquiry';

export interface ContactEnquiry {
  id: string;
  name: string;
  email: string;
  category: EnquiryCategory;
  serviceType?: string;
  subject: string;
  message: string;
  createdAt: string;
  status: 'unread' | 'reviewed' | 'resolved' | 'new' | 'in_review';
}

export type NexaEnquiry = ContactEnquiry;

export type ScreenshotCategory =
  | 'All'
  | 'Home'
  | 'NEXA AI'
  | 'Hey NEXA'
  | 'NEXA Tools'
  | 'Finance'
  | 'Settings'
  | 'Login'
  | 'FocusLock integration';

export interface NexaScreenshot {
  id: string;
  title: string;
  category: Exclude<ScreenshotCategory, 'All'>;
  description: string;
  badge?: string;
  mockupType: 'assistant' | 'voice' | 'tools' | 'finance' | 'security' | 'focuslock';
  order: number;
}

export interface HelpArticle {
  id: string;
  section: 'general' | 'ai';
  category: string;
  title: string;
  summary: string;
  content: string[];
  androidSpecific: boolean;
  tags: string[];
}

export interface ServiceOffering {
  id: string;
  title: string;
  tagline: string;
  category: string;
  description: string;
  deliverables: string[];
  technologies: string[];
  icon: string;
}
