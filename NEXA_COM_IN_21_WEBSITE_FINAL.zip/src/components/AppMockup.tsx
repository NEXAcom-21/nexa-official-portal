import React, { useState } from 'react';
import {
  Sparkles,
  Mic,
  Shield,
  Calculator,
  PhoneCall,
  Sliders,
  Send,
  Lock,
  Battery,
  Wifi,
  Signal,
  Flame,
  CheckCircle2,
  Clock,
  ArrowRight
} from 'lucide-react';

export const AppMockup: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ai' | 'voice' | 'focuslock' | 'tools'>('ai');

  return (
    <div id="nexa-interactive-device-mockup" className="relative mx-auto w-full max-w-[340px] sm:max-w-[380px]">
      {/* Outer Glow Backdrop */}
      <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500/30 via-blue-600/20 to-cyan-400/30 rounded-[42px] blur-xl opacity-75"></div>

      {/* Hardware Frame */}
      <div className="relative rounded-[40px] border-[6px] border-slate-800 bg-[#050b14] p-3 shadow-2xl ring-1 ring-cyan-500/30 overflow-hidden">
        {/* Top Speaker / Camera Pill */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full flex items-center justify-between px-3 z-30 border border-slate-800">
          <div className="w-2 h-2 rounded-full bg-slate-800"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-900/60 border border-cyan-500/40 flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-cyan-400"></div>
          </div>
        </div>

        {/* Screen Bezel */}
        <div className="rounded-[30px] bg-[#070e1c] border border-slate-800/80 overflow-hidden flex flex-col h-[600px] text-slate-100">
          {/* Status Bar */}
          <div className="pt-2 px-5 pb-1 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none">
            <span>09:41</span>
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3 text-cyan-400" />
              <Wifi className="w-3 h-3 text-cyan-400" />
              <div className="flex items-center gap-0.5">
                <span className="text-[10px]">98%</span>
                <Battery className="w-3.5 h-3.5 text-emerald-400" />
              </div>
            </div>
          </div>

          {/* App Header */}
          <div className="px-4 py-2 border-b border-slate-800/80 flex items-center justify-between bg-[#040812]/90">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-[10px] font-bold text-cyan-400">
                NX
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1">
                  NEXA Android
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                </div>
                <div className="text-[9px] text-cyan-400 font-mono">v2.2 Native Engine</div>
              </div>
            </div>
            <div className="px-2 py-0.5 rounded-full bg-cyan-950/60 text-[10px] font-mono text-cyan-300 border border-cyan-500/30">
              System Ready
            </div>
          </div>

          {/* Screen Content Based on Active Tab */}
          <div className="flex-1 p-3.5 overflow-hidden flex flex-col justify-between">
            {activeTab === 'ai' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-2.5 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-xs">
                  <div className="flex items-center gap-1.5 text-cyan-400 font-semibold mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    NEXA Neural Core
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    "Morning Alex! You have 3 urgent items today. I've prepared your daily brief and calibrated your FocusLock schedule."
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="ml-auto max-w-[85%] p-2.5 rounded-xl bg-blue-600/30 border border-blue-500/30 text-right">
                    <p className="text-xs text-white">"Prepare an EMI breakdown for 25 Lakhs loan @ 8.5% for 15 years."</p>
                    <span className="text-[9px] text-slate-400">09:39 AM</span>
                  </div>

                  <div className="max-w-[90%] p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                    <div className="text-xs font-semibold text-cyan-300 mb-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      Offline Calculation Ready
                    </div>
                    <p className="text-[11px] text-slate-300">
                      • Monthly EMI: <strong className="text-white">₹24,618</strong>
                      <br />• Total Interest: <strong className="text-white">₹19,31,240</strong>
                      <br />• Total Payable: <strong className="text-white">₹44,31,240</strong>
                    </p>
                  </div>
                </div>

                <div className="pt-2">
                  <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400">
                    <span className="truncate">Type a message to NEXA...</span>
                    <Send className="w-3.5 h-3.5 text-cyan-400 ml-auto" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'voice' && (
              <div className="flex flex-col items-center justify-center flex-1 space-y-5 text-center animate-in fade-in duration-200">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center animate-pulse">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_30px_rgba(6,182,212,0.6)]">
                      <Mic className="w-8 h-8 text-slate-950 stroke-[2.5]" />
                    </div>
                  </div>
                  <div className="absolute -inset-2 rounded-full border border-cyan-400/20 animate-ping pointer-events-none"></div>
                </div>

                <div className="space-y-1">
                  <div className="inline-block px-3 py-1 rounded-full bg-cyan-950/80 text-cyan-300 text-xs font-mono border border-cyan-500/40">
                    "Hey NEXA" Activated
                  </div>
                  <h4 className="text-sm font-bold text-white">Listening to voice command...</h4>
                  <p className="text-[11px] text-slate-400">
                    "Call Rahul Mobile" • "Launch Finance" • "Set 30 min Focus"
                  </p>
                </div>

                <div className="w-full p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-left text-xs space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Recognized Intent</div>
                  <div className="flex items-center justify-between text-white font-medium">
                    <span className="flex items-center gap-1.5">
                      <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                      Initiate Direct Call: Rahul Sharma
                    </span>
                    <span className="text-[10px] text-cyan-400 font-mono">Auto-dialing</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'focuslock' && (
              <div className="space-y-4 animate-in fade-in duration-200 flex-1 flex flex-col justify-center">
                <div className="p-4 rounded-2xl bg-gradient-to-b from-slate-900 to-[#091122] border border-cyan-500/30 text-center space-y-3">
                  <div className="w-10 h-10 mx-auto rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-cyan-400 font-mono">
                      Deep Focus Session Active
                    </div>
                    <div className="text-3xl font-mono font-bold text-white tracking-tight mt-1">
                      00:43:18
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      Distracting social apps locked
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-left pt-1">
                    <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-[10px]">
                      <span className="text-slate-400">Blocked Apps:</span>
                      <p className="font-bold text-slate-200 mt-0.5">8 Applications</p>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-[10px]">
                      <span className="text-slate-400">Emergency Override:</span>
                      <p className="font-bold text-cyan-300 mt-0.5">PIN Protected</p>
                    </div>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
                  <span className="text-[11px] text-slate-400">Emergency Contact Whitelist: <strong className="text-white">Active</strong></span>
                </div>
              </div>
            )}

            {activeTab === 'tools' && (
              <div className="space-y-2.5 animate-in fade-in duration-200">
                <div className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                  Android Native Tools
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-left">
                    <Sliders className="w-4 h-4 text-cyan-400 mb-1" />
                    <div className="text-xs font-bold text-white">Audio Profile</div>
                    <div className="text-[10px] text-slate-400">Meeting Mute (Active)</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-left">
                    <Calculator className="w-4 h-4 text-emerald-400 mb-1" />
                    <div className="text-xs font-bold text-white">SIP Calculator</div>
                    <div className="text-[10px] text-slate-400">₹10K/mo = ₹1.1 Cr</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-left">
                    <Clock className="w-4 h-4 text-purple-400 mb-1" />
                    <div className="text-xs font-bold text-white">Alarms</div>
                    <div className="text-[10px] text-slate-400">Synced to native clock</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-left">
                    <Lock className="w-4 h-4 text-amber-400 mb-1" />
                    <div className="text-xs font-bold text-white">App Vault</div>
                    <div className="text-[10px] text-slate-400">Biometrics Guard</div>
                  </div>
                </div>
                <div className="p-2 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-[10px] text-cyan-200">
                  ⚡ All calculators and system switches execute 100% offline.
                </div>
              </div>
            )}

            {/* In-Mockup Preview Switcher Tabs */}
            <div className="mt-auto pt-2 border-t border-slate-800/80 grid grid-cols-4 gap-1">
              <button
                id="mockup-tab-ai"
                onClick={() => setActiveTab('ai')}
                className={`py-1.5 rounded-lg flex flex-col items-center justify-center text-[9px] font-medium transition-colors cursor-pointer ${
                  activeTab === 'ai'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 mb-0.5" />
                NEXA AI
              </button>
              <button
                id="mockup-tab-voice"
                onClick={() => setActiveTab('voice')}
                className={`py-1.5 rounded-lg flex flex-col items-center justify-center text-[9px] font-medium transition-colors cursor-pointer ${
                  activeTab === 'voice'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Mic className="w-3.5 h-3.5 mb-0.5" />
                Hey NEXA
              </button>
              <button
                id="mockup-tab-focuslock"
                onClick={() => setActiveTab('focuslock')}
                className={`py-1.5 rounded-lg flex flex-col items-center justify-center text-[9px] font-medium transition-colors cursor-pointer ${
                  activeTab === 'focuslock'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5 mb-0.5" />
                FocusLock
              </button>
              <button
                id="mockup-tab-tools"
                onClick={() => setActiveTab('tools')}
                className={`py-1.5 rounded-lg flex flex-col items-center justify-center text-[9px] font-medium transition-colors cursor-pointer ${
                  activeTab === 'tools'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 mb-0.5" />
                Tools
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mockup Caption */}
      <p className="text-center text-xs text-slate-400 mt-3 font-medium">
        Interactive UI Preview of the NEXA Android App (v2.2)
      </p>
    </div>
  );
};
